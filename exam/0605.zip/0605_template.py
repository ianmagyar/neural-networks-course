import keras
import pandas as pd
import numpy as np
# add all necessary imports here


# TASK 1: load dataset as csv file (2)


# TASK 2: select at least 7 features; one must be string - vectorize it; last column is the predict class (3)


# TASK 3: process NaN values (1)


# TASK 4: create training and testing set - analyze if stratified sampling is necessary (4)


# TASK 5: define neural net (4)


# TASK 6: train neural net (2)


# TASK 7: evaluate neural net, print confusion matrix (4)
