import pandas as pd
dataset = pd.read_csv('iris.csv')
print(dataset)

# select only column SepalLengthCm
print(dataset['SepalLengthCm'])

# select columns SepalLengthCm and SepalWidthCm
print(dataset[['SepalLengthCm', 'SepalWidthCm']])

print(dataset.SepalLengthCm)
print(dataset.iloc[:, 0])

print(dataset[0:10:2])

print(dataset.loc[0:9:2])
print(dataset.iloc[0:9:2])

print(dataset[:10:2]['SepalLengthCm'])
print(dataset['SepalLengthCm'][:10:2])

print(dataset.loc[lambda df:df.SepalLengthCm > 5, :])

dataset['SepalLengthCm'][:10:].values


import seaborn as sns
import matplotlib.pyplot as plt

# set plot style
sns.set(style="ticks")
sns.set_palette("husl")

# create plots over all dataset; for subset use iloc indexing
sns.pairplot(dataset, hue="Species")

# display plots using matplotlib
plt.show()

# split data into input (X - select the first four columns) and output (y - select last column)
X = dataset.iloc[:, :4].values
y = dataset.iloc[:, -1].values


from sklearn.preprocessing import LabelEncoder

encoder = LabelEncoder()
# transform string labels into number values 0, 1, 2
y1 = encoder.fit_transform(y)

# transform number values into vector representation
Y = pd.get_dummies(y1).values


from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)


from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam

model = Sequential()

model.add(Dense(10,input_shape=(4,),activation='tanh'))
# TODO: add dense layer with 8 neurons and tanh activation function
model.add(Dense(8, activation='tanh'))
# TODO: add dense layer with 6 neurons and tanh activation function
model.add(Dense(6, activation='tanh'))
# TODO: add dense layer with 3 neurons and softmax activation function
model.add(Dense(3, activation='softmax'))


model.compile(Adam(lr=0.04), 'categorical_crossentropy', metrics=['accuracy'])


model.fit(X_train, y_train, epochs=100)


y_pred = model.predict(X_test)

import numpy as np

y_test_class = np.argmax(y_test,axis=1)
y_pred_class = np.argmax(y_pred,axis=1)

from sklearn.metrics import classification_report, confusion_matrix

print(confusion_matrix(y_test_class, y_pred_class))
print(classification_report(y_test_class, y_pred_class))
